import React from 'react'

const Card = ({data}) => {
     

  return (
    <div>
        <div className='Card'>
          <Card >
            </Card>  
          
        </div>
    </div>
  )
}

export default Card