import React from 'react'

const ForRent = () => {
  return (
    <div>ForRent</div>
  )
}

export default ForRent