import React from 'react'

const Sell = () => {
  return (
    <div>Sell</div>
  )
}

export default Sell