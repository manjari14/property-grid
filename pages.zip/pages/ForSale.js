import React from 'react'

const ForSale = () => {
  return (
    <div>ForSale</div>
  )
}

export default ForSale