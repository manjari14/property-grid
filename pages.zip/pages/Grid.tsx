import React from 'react'
import Card from './Card'
import { MockData } from './MockData'

const Grid = () => {
   
  return (
    <div>
        {MockData.map((item)=>{
            return(
                <Card data={item}/>

            )
        })}
        
    </div>
  )
}

export default Grid